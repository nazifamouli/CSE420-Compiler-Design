/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_420;

import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Nazifa
 */
public class Lab4_420 {
    public static void main(String[] args) {
      try{
        File fileName=new File("read.txt");
        Scanner sc=new Scanner(fileName);
        while(sc.hasNext()){
       String line1 = sc.nextLine();
       String line2 = sc.next();

       if (line1.contains("(") && line2.contains("{")){

        String[] t1 = line1.split("\\(");

        String[] arr = t1[0].split(" ");
        
        int t = arr.length;
        System.out.print(arr[t-1]);
     
        String p2 = "("+t1[1];
        System.out.print(p2);
        
        System.out.println(", return type: "+ arr[t-2]);

       }
     }
      }
      catch( Exception e ){
          
      }
    }
    
}
