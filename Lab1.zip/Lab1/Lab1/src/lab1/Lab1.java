/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;
  
import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.ListIterator;
import java.util.Scanner;
import java.util.Set;
import java.io.FileNotFoundException;
import java.io.*;
import java.util.*;
import java.util.Iterator;

/**
 *
 * @author Nazifa
 */
public class Lab1 {

    static String[] keyword={"int" , "float" , "double" , "if" , "else" , "for" ,"static" ,"main", "void" ,"public"};
    static String[] math_operator = {"+" , "-" , "*" , "/" ,"=","++","--"};
    static String[] logical_operator = {"<" , ">" , "==" , "!=" , "<=" ,">="};
    static String[] other = {"," , ";" , "(" , ")" , "{" , "}"}; 
    static String[] splitA;
    static String[] splitB;

    static ArrayList<String> a = new ArrayList<String>(); 
    static ArrayList<String> b = new ArrayList<String>();
    
    public static void main(String[] args) {  
        try{
            
        Set<String> keys = new HashSet<String>();
       Set<String> math_op = new HashSet<String>();
        Set<String> logical_op = new HashSet<String>();
        Set<String> others = new HashSet<String>();
       Set<String> numerical = new HashSet<String>();
        Set<String> identifier = new HashSet<String>();
       

        File fileName=new File("read.txt");
        Scanner sc=new Scanner(fileName);

        while(sc.hasNextLine() ){
            String line = sc.nextLine();

            splitA =line.split("\\W+");
            splitB =line.split("\\w");

            for(String splitA_element : splitA){
                 a.add(splitA_element.trim());                 
            }
            for(String splitA_element : splitB){
                 b.add(splitA_element.trim());                 
            }  
        }
         
         for(String w : a){
             if(match(w,keyword)){
               keys.add(w);
             }
             else if(isInteger(w)){
                numerical.add(w);
             }
             else{
                 identifier.add(w);
             }
         }
  
         for(String op : b){
             if(match(op,math_operator)){
                math_op.add(op);
             }
             else if(match(op,logical_operator)){
                 logical_op.add(op);
             }
             else if(match(op,other)){
                 others.add(op);
             }
         }
          System.out.println("Keywords: "+keys);
          System.out.println("Identifier: "+identifier);
          System.out.println("Math Operator: "+math_op);
          System.out.println("Logical Values: "+logical_op);
          System.out.println("Numerical Values: "+numerical);
           System.out.println("Others: "+others);
        }

        catch(Exception e){
            
        }
    }
    public static boolean isInteger( String input ) {
    try {  
        Integer.parseInt( input ); 
        return true; 
    } 
    catch( Exception e ) {  
        return false; 
    } 
   }
  public static boolean match( String key, String[] arr ) {
       for(String x : arr){
          if(x.equals(key)){
              return true;  
         }       
       }
      return false;
   }
}
   

    