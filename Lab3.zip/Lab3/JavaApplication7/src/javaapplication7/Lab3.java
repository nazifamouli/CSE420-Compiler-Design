/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication7;
import java.util.Scanner;
import java.util.regex.*;
/**
 *
 * @author Nazifa
 */
public class Lab3 {
    public static void main(String[] args) {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter Input");
      int num1=sc.nextInt();
      String ptt[]=new String[num1];
      sc.nextLine();      
      for(int i=0;i< num1 ; i++){
        ptt[i]=sc.nextLine();
      }
      Pattern p; Matcher m;String s; boolean b; int ind;
      int num2=sc.nextInt();
      String result[]=new String[num2];
      sc.nextLine();
      for(int i=0;i<num2;i++){
          s=sc.nextLine();
          b=false;
          ind=0;
          for(int j=0;j<num1;j++){
              p=Pattern.compile(ptt[j]);
              m=p.matcher(s);

              if(m.matches()==true){
                 b=m.matches();
                 ind=j+1;
              }              
          }
          result[i]=matching(b,ind);
      }
      for(int i=0;i<num2;i++){
          System.out.println(result[i]);
      }
    }
    public static String matching(boolean b,int ind){
        if(b==true){
            return"YES,"+ind;
        }
        else{
            return "N0,"+ind;
        }   
    }
}
