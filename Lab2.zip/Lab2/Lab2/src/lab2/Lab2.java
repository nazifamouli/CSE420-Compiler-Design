/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2;

/**
 *
 * @author Nazifa
 */
import java.util.*;
import java.util.Scanner;

public class Lab2 {

  public static boolean isValidEmailAddress(String str) {
    boolean checkEndDot;
    boolean checkEndAt;
    boolean checkEndDash;

    checkEndDot = str.endsWith(".");
    checkEndAt = str.endsWith("@");
    checkEndDash = str.endsWith("-");
    String[] chunks = str.split("@");
    String userName  = chunks[0];
    String domainName = chunks[1];
    String[] emailDomainParts = domainName.split("\\.");
    String lastemailDomainPart = emailDomainParts[emailDomainParts.length - 1];
    int countOfAt = 0;
    int countDomainDots = 0;

    for (int i = 0; i < str.length(); i++) {
      if(str.charAt(i)=='@') {
        countOfAt++;
      } 
    }

    for (int i = 0; i < domainName.length(); i++) {
      if(domainName.charAt(i)=='.') {
        countDomainDots++;
      } 
    }

    if (checkEndDot || checkEndAt || checkEndDash || countOfAt!=1 ){
      return false;
    }

    if ( !(str.charAt(0) >='a' && str.charAt(0) <= 'z') || chunks.length != 2 ) {
      return false;
    }

    if (userName.length() < 1 || domainName.length() < 3 || countDomainDots < 1) {
      return false;
    }

    for (int i = 0; i < userName.length(); i += 1) {
      if( !(domainName.charAt(i) >='a' && domainName.charAt(i) <= 'z') && !( domainName.charAt(i) !='.' ) && !(domainName.charAt(i) !='-') ) {
        return false;
        }
    }

    for(int j = 0; j < domainName.length(); j += 1) {
      if( !Character.isDigit(domainName.charAt(j)) && !(domainName.charAt(j) >='a' && domainName.charAt(j) <= 'z') && !( domainName.charAt(j) !='.' ) && !(domainName.charAt(j) !='-') ) {
        return false;
        }
    }

    for (int i = 0; i < lastemailDomainPart.length(); i++) {
      if(!(lastemailDomainPart.charAt(i) >='a' && lastemailDomainPart.charAt(i)<='z') )
      {
          return false;
      }
    }

    return true;
}


  public static boolean isValidWebsite(String str) {
    String[] chunks = str.split("\\.");

    if (chunks.length != 3) {
      return false;
    }

    String wPart = chunks[0];
    String middlePart = chunks[1];
    String endPart = chunks[2];

    if (wPart.length() != 3) {
      return false;
    }

    for (int i = 0; i < middlePart.length(); i++) {
        if(!(middlePart.charAt(i) >='a' && middlePart.charAt(i)<='z') )
        {
            return false;
        }
    }

    for (int i = 0; i < endPart.length(); i++) {
        if(!(endPart.charAt(i) >='a' && endPart.charAt(i)<='z') )
        {
            return false;
        }
    }

    return true;
  }
     
  public static void main(String[] args) {
        
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter the number of Regular Expression");
      int expNum = sc.nextInt();
      String exp[] = new String[expNum]; 
      System.out.println("Expressions are: ");
      
      for (int i = 0; i < exp.length; i++) { 
        exp[i] = sc.next();
      }

      String str;
      boolean flag;
        
      for(int i=0; i < expNum; i++) {
        str = exp[i].trim();

        if (str.contains("@")) {
          flag = isValidEmailAddress(str);

          if (flag) {
            System.out.println("Email Address " + (i+1) );
          }
          else {
            System.out.println("Not a valid Email Address");
          }
        }

        else if (str.startsWith("www")) {
          flag = isValidWebsite(str);

          if (flag) {
            System.out.println("Website " + (i+1) );
          }
          else {
            System.out.println("Not a valid Website");
          }
        }
        else {
          System.out.println("Invalid Input");
        }
      }
  }
}